PING PONG — Android APK build starter

Files:
- main.py: Kivy ping-pong game
- buildozer.spec: Android packaging settings
- .github/workflows/build-apk.yml: cloud build workflow

Phone-only outline:
1. Extract this ZIP on your phone.
2. Create a GitHub repository and upload these files, including the hidden .github folder.
3. Open the repository's Actions tab, select "Build Android APK", then tap "Run workflow".
4. When the run finishes, download the "ping-pong-debug-apk" artifact.

This workflow is a starter, not a tested or guaranteed APK. Build tools can change and the first build may fail. The resulting debug APK is for testing; Myket may require a signed release package and developer registration. Ask a parent/guardian to help with account, identity, or payment steps if required.
